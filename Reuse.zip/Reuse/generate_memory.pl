use strict;
use warnings;

# Number of address-data pairs
my $num_entries = 256;

# Open the file to write the memory content
my $file_path = "memory_file_2.mem";
open(my $fh, '>', $file_path) or die "Could not open file '$file_path': $!";

# Generate and write the addresses and data to the file
for (my $i = 0; $i < $num_entries; $i++) {
    my $address = sprintf("%04X", $i);
    my $data = sprintf("%04X", ($i * 3) % 0x10000);
    print $fh "\@$address $data\n";
}

close($fh);

print "Memory file '$file_path' created successfully.\n";
